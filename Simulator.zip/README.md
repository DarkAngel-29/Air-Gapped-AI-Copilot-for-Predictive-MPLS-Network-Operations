# Air-Gapped AI Copilot for Predictive MPLS Network Operations

## Stage 1: MPLS Network Simulator Module

This repository contains the independent **MPLS Network Simulator** module for the college Software Engineering project *“Air-Gapped AI Copilot for Predictive MPLS Network Operations”*.

---

### System Architecture Boundary

```
+--------------------------------------------------------------+
|                    MPLS Network Simulator                    |
|   (Virtual Routers • Stochastic Physics • Fault Injection)   |
+--------------------------------------------------------------+
                                |
                                v
               Generated Telemetry Stream (JSON Lines)
                                |
                                v
+--------------------------------------------------------------+
|            Local Structured Log Storage                      |
|                  logs/telemetry.jsonl                        |
+--------------------------------------------------------------+
                                |
                                v  (Future Stages - Separate)
+--------------------------------------------------------------+
|   Log Collection & Processing -> Database -> AI Analytics   |
+--------------------------------------------------------------+
```

> **Important Boundary Rule**: The simulator's sole responsibility is creating configurable virtual MPLS routers, simulating network behavior, and producing machine-readable structured telemetry logs. The simulator **does not** perform anomaly detection, failure prediction, ML models, or dashboard analytics.

---

### Features & Capabilities

1. **Dynamic Virtual Routers**:
   - Create as many virtual routers as needed (`R1`, `R2`, `R3`, `R4`, `R5`, `R6`, ...).
   - Each card displays Router ID, descriptive name, and status (`ACTIVE`, `FAULTED`, `OFFLINE`).
   - Clean, uncluttered interface preserving the tactile 3D clay aesthetic.

2. **Real-Time Telemetry Hover Popover**:
   - Hovering over any router card reveals live dynamic metrics:
     - **Latency** (ms)
     - **Packet Loss** (%)
     - **Jitter** (ms)
     - **Bandwidth Usage** (%) with visual gauge
     - **CPU Usage** (%) with visual gauge
     - **Memory Usage** (%) with visual gauge

3. **Stochastic Physics Engine**:
   - Realistic baselines with natural mean-reversion drift and sensible cross-metric correlations (e.g. queue buildup when bandwidth > 70% or CPU > 70% introduces queuing latency and packet jitter).

4. **Controlled Fault Injection**:
   - Target Router selection across all provisioned nodes.
   - Fault Types:
     - `Latency Spike`
     - `Packet Loss Spike`
     - `High Jitter`
     - `Bandwidth Congestion`
     - `CPU Overload`
     - `Memory Overload`
     - `Link Failure`
   - Configurable **Duration** (10s, 15s, 30s, 60s, 120s) and **Intensity** (Low, Medium, High).
   - Faulted routers transition to `FAULTED` status, display active perturbation banner with countdown timer, and automatically recover toward normal baseline upon expiration.

5. **Local Persistent Log Storage**:
   - Continually appends all generated telemetry records to `logs/telemetry.jsonl`.
   - Thread-safe, machine-readable JSON Lines format ready for ingestion by downstream pipeline modules.

---

### Project Structure

```
d:\Projects\Software Engg\
├── logs\
│   └── telemetry.jsonl          # Persisted JSON Lines log file
├── simulator\
│   ├── __init__.py
│   ├── models.py                # Data structures: Router, Fault, TelemetryRecord
│   ├── storage.py               # Local persistent JSON Lines storage manager
│   ├── engine.py                # Real-time simulation & stochastic telemetry engine
│   └── server.py                # FastAPI REST API & static web server
├── static\
│   ├── index.html               # Tactile clay simulator web interface
│   └── app.js                   # Real-time frontend controller & polling
├── Generator UI\
│   ├── code.html                # Standalone simulator UI (tactile clay interface)
│   └── DESIGN.md                # Tactile clay design system tokens
├── run_simulator.py             # One-click simulator runner
├── test_simulator.py            # Automated test suite (7 tests)
└── README.md                    # Project documentation
```

---

### How to Run the Simulator

#### 1. Start the Simulator Server

Run the Python launcher in your terminal:

```bash
python run_simulator.py
```

This will:
- Initialize the simulation engine with default nodes (`R1`, `R2`, `R3`, `R4`).
- Start real-time telemetry generation and log writing to `logs/telemetry.jsonl`.
- Host the REST API and tactile web UI at `http://127.0.0.1:8000`.
- Automatically open `http://127.0.0.1:8000` in your web browser.

#### 2. Run the Verification Test Suite

To verify all simulator components automatically:

```bash
python test_simulator.py
```

Tests run in under 0.1s and verify:
- Default router initialization.
- Dynamic router creation (`R5`, `R6`...).
- Metric variation and baseline stability.
- Fault injection behavior (`CPU Overload`, `Latency Spike`).
- Fault countdown and baseline recovery.
- Local JSON Lines log persistence and schema conformance.

---

### Telemetry Record Schema

Every generated record saved in `logs/telemetry.jsonl` contains:

```json
{
  "timestamp": "2026-10-08T14:29:42.441Z",
  "router_id": "R1",
  "latency": 14.44,
  "packet_loss": 0.08,
  "jitter": 2.73,
  "bandwidth_usage": 45.6,
  "cpu_usage": 34.2,
  "memory_usage": 35.5,
  "status": "ACTIVE",
  "active_fault": null
}
```

Under active fault conditions:

```json
{
  "timestamp": "2026-10-08T14:28:15.120Z",
  "router_id": "R3",
  "latency": 82.50,
  "packet_loss": 1.75,
  "jitter": 16.30,
  "bandwidth_usage": 48.0,
  "cpu_usage": 94.6,
  "memory_usage": 42.1,
  "status": "FAULTED",
  "active_fault": "CPU Overload"
}
```
